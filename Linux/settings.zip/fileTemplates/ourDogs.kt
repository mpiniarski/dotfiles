package pages

import Dog
import containers.Header.Header
import containers.OurDog.OurDog
import containers.OurDog.OurDogProps
import extensions.invoke
import extensions.reactFC
import js.styledComponents.asCSS
import js.styledComponents.styled

val dog = Dog(
  name = "Letti",
  breedName = "LEA Elvikam",
  title = "",
  birthDate = "2013-01-23",
  gender = "Suczka",
  mother = "GRACJA",
  father = "MAMBO",
  acc = "3 x ocena doskonala",
  imgUrl = "http://milaletti.pl/api/v1/files/771"
)

val OurDogsPage = reactFC {
  Header {}
  PageContainer(this) {
    Title(this) { +"Nasze psy" }
    Button(this) { +"Dodaj psa" }
    (1 .. 8).map {
      OurDog(OurDogProps(dog)) {}
    }
  }
}

internal val Title = styled.h1 {
  """
  """
}

internal val Button = styled.button {
  """
  """
}

internal val PageContainer = styled.div {
  """
  display: flex;
  flex-direction: column;
  width: 80%;
  margin: 20px auto;
  & > div {
    margin-top: 30px
  }
  """.asCSS()
}
